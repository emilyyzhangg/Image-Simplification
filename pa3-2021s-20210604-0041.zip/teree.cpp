/**
 * CPSC 221 - 2021S
 * PA3
 * Ternary Tree
 *
 * This file will be submitted for grading.
 *
 */

#include "teree.h"

// Node constructor, given.
Teree::Node::Node(pair<int, int> ul, int w, int h, Node* par)
	:upperleft(ul), width(w), height(h), parent(par), A(NULL), B(NULL), C(NULL)
{ }

// Teree destructor, given.
Teree::~Teree() {
	Clear();
}

// Teree copy constructor, given.
Teree::Teree(const Teree& other) {
	Copy(other);
}

// Teree assignment operator, given.
Teree& Teree::operator=(const Teree& rhs) {
	if (this != &rhs) {
		Clear();
		Copy(rhs);
	}
	return *this;
}


Teree::Teree(PNG& imIn) {
	// YOUR CODE HERE
}

void Teree::Clear() {
	// YOUR CODE HERE
}

void Teree::Copy(const Teree& other) {
	// YOUR CODE HERE
}

PNG Teree::Render() const {
	// YOUR CODE HERE
}

void Teree::Prune(double tol) {
	// YOUR CODE HERE
}

int Teree::NumLeaves() const {
	// YOUR CODE HERE
}

Teree::Node* Teree::BuildNode(PNG& im, pair<int, int> ul, int w, int h, Teree::Node* par) {
	// YOUR CODE HERE
}

/*==== ALSO IMPLEMENT ANY PRIVATE FUNCTIONS YOU HAVE DECLARED ====*/